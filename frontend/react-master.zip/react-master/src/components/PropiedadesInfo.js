import React, { Fragment } from 'react';
import Img2 from './Slider/Img2';
import Pinfo from './Textos/Pinfo';

function PropiedadesInfo() {

    return (
        <Fragment>
            <Img2 />
            <Pinfo />

        </Fragment>
    )
}
export default PropiedadesInfo;