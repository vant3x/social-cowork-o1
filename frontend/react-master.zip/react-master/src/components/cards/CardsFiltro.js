import React, { Fragment } from 'react';
import '../cards/card.css';


function CardsFiltro() {

    const NuncaExpandirse = {
        verticalAlign: 'inherit'
    }

    return (
        <Fragment>
             <div className="text-center">
                    <div className=" cover-container d-flex w-100 p-3 mx-auto flex-column navegar">

                        <main role="main">

                            <div className="album py-3 ">
                                <div className="container">

                                    <div className="row">
                                        <div className="col-md-4">
                                            <div className="card mb-1 ">

                                          
    
                                                   <img src="img/home1.jpg" className="img"></img>
                                                   
              
                                                <div className="card-body">
                                                    <p className="card-text">
                                                        <font style={NuncaExpandirse}>
                                                        <h5 class="card-title">Card title</h5>
    
                                                            <font style={NuncaExpandirse}>Esta es una tarjeta más amplia
                                                                con texto de apoyo a continuación como una introducción natural a
                                                    contenido adicional. </font>
                                                            <font style={NuncaExpandirse}>Este contenido es un poco más
                                                    largo.</font>
                                                        </font>
                                                    </p>
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="btn-group">
                                                            <button type="button" className="btn btn-sm btn-outline-secondary">
                                                                <font style={NuncaExpandirse}>
                                                                    <a style={NuncaExpandirse} href="/Propiedadesinfo">Ver</a>
                                                                </font>
                                                            </button>
                                                          
                                                        </div>
                                                        <small className="text-muted">
                                                            <font style={NuncaExpandirse}>
                                                                <font style={NuncaExpandirse}>9 minutos</font>
                                                            </font>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            <div className="card mb-4 shadow-sm">

                                            <img src="img/home2.jpg" className="img"></img>
                                               
                                                <div className="card-body">
                                                    <p className="card-text">
                                                        <font style={NuncaExpandirse}>
                                                        <h5 class="card-title">Card title</h5>
    
                                                            <font style={NuncaExpandirse}>Esta es una tarjeta más amplia
                                                                con texto de apoyo a continuación como una introducción natural a
                                                    contenido adicional. </font>
                                                            <font style={NuncaExpandirse}>Este contenido es un poco más
                                                    largo.</font>
                                                        </font>
                                                    </p>
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="btn-group">
                                                            <button type="button" className="btn btn-sm btn-outline-secondary">
                                                                <font style={NuncaExpandirse}>
                                                                <a style={NuncaExpandirse} href="/Propiedadesinfo">Ver</a>
                                                                </font>
                                                            </button>
                                                         
                                                        </div>
                                                        <small className="text-muted">
                                                            <font style={NuncaExpandirse}>
                                                                <font style={NuncaExpandirse}>9 minutos</font>
                                                            </font>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            <div className="card mb-4 shadow-sm">
                                              
                                            <img src="img/home3.jpg" className="img"></img>

                                                <div className="card-body">
                                                    <p className="card-text">
                                                        <font style={NuncaExpandirse}>
                                                        <h5 class="card-title">Card title</h5>
    
                                                            <font style={NuncaExpandirse}>Esta es una tarjeta más amplia
                                                                con texto de apoyo a continuación como una introducción natural a
                                                    contenido adicional. </font>
                                                            <font style={NuncaExpandirse}>Este contenido es un poco más
                                                    largo.</font>
                                                        </font>
                                                    </p>
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="btn-group">
                                                            <button type="button" className="btn btn-sm btn-outline-secondary">
                                                                <font style={NuncaExpandirse}>
                                                                <a style={NuncaExpandirse} href="/Propiedadesinfo">Ver</a>
                                                                </font>
                                                            </button>
                                                         
                                                        </div>
                                                        <small className="text-muted">
                                                            <font style={NuncaExpandirse}>
                                                                <font style={NuncaExpandirse}>9 minutos</font>
                                                            </font>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </div>


                        </main>
                    </div>
                </div>


                <div className="text-center">
                    <div className=" cover-container d-flex w-100 p-3 mx-auto flex-column navegar">

                        <main role="main">

                            <div className="album py-5 ">
                                <div className="container">

                                    <div className="row">
                                        <div className="col-md-4">
                                            <div className="card mb-4 ">

                                          
    
                                                   <img src="img/home1.jpg" className="img"></img>
                                                   
              
                                                <div className="card-body">
                                                    <p className="card-text">
                                                        <font style={NuncaExpandirse}>
                                                        <h5 class="card-title">Card title</h5>
    
                                                            <font style={NuncaExpandirse}>Esta es una tarjeta más amplia
                                                                con texto de apoyo a continuación como una introducción natural a
                                                    contenido adicional. </font>
                                                            <font style={NuncaExpandirse}>Este contenido es un poco más
                                                    largo.</font>
                                                        </font>
                                                    </p>
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="btn-group">
                                                            <button type="button" className="btn btn-sm btn-outline-secondary">
                                                                <font style={NuncaExpandirse}>
                                                                    <a style={NuncaExpandirse} href="/Propiedadesinfo">Ver</a>
                                                                </font>
                                                            </button>
                                                          
                                                        </div>
                                                        <small className="text-muted">
                                                            <font style={NuncaExpandirse}>
                                                                <font style={NuncaExpandirse}>9 minutos</font>
                                                            </font>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            <div className="card mb-4 shadow-sm">

                                            <img src="img/home2.jpg" className="img"></img>
                                               
                                                <div className="card-body">
                                                    <p className="card-text">
                                                        <font style={NuncaExpandirse}>
                                                        <h5 class="card-title">Card title</h5>
    
                                                            <font style={NuncaExpandirse}>Esta es una tarjeta más amplia
                                                                con texto de apoyo a continuación como una introducción natural a
                                                    contenido adicional. </font>
                                                            <font style={NuncaExpandirse}>Este contenido es un poco más
                                                    largo.</font>
                                                        </font>
                                                    </p>
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="btn-group">
                                                            <button type="button" className="btn btn-sm btn-outline-secondary">
                                                                <font style={NuncaExpandirse}>
                                                                <a style={NuncaExpandirse} href="/Propiedadesinfo">Ver</a>
                                                                </font>
                                                            </button>
                                                         
                                                        </div>
                                                        <small className="text-muted">
                                                            <font style={NuncaExpandirse}>
                                                                <font style={NuncaExpandirse}>9 minutos</font>
                                                            </font>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            <div className="card mb-4 shadow-sm">
                                              
                                            <img src="img/home3.jpg" className="img"></img>

                                                <div className="card-body">
                                                    <p className="card-text">
                                                        <font style={NuncaExpandirse}>
                                                        <h5 class="card-title">Card title</h5>
    
                                                            <font style={NuncaExpandirse}>Esta es una tarjeta más amplia
                                                                con texto de apoyo a continuación como una introducción natural a
                                                    contenido adicional. </font>
                                                            <font style={NuncaExpandirse}>Este contenido es un poco más
                                                    largo.</font>
                                                        </font>
                                                    </p>
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="btn-group">
                                                            <button type="button" className="btn btn-sm btn-outline-secondary">
                                                                <font style={NuncaExpandirse}>
                                                                <a style={NuncaExpandirse} href="/Propiedadesinfo">Ver</a>
                                                                </font>
                                                            </button>
                                                         
                                                        </div>
                                                        <small className="text-muted">
                                                            <font style={NuncaExpandirse}>
                                                                <font style={NuncaExpandirse}>9 minutos</font>
                                                            </font>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </div>


                        </main>
                    </div>
                </div>






        </Fragment>
       



    )
}

export default CardsFiltro;